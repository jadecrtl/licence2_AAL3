// symboles, sont utilisés dans les jetons

public enum Sym {
    INT, IDENT, PARG, PARD, MULT, PLUS;
}


