jflex $1.jflex
javac Lexer.java
java Lexer $1.txt
